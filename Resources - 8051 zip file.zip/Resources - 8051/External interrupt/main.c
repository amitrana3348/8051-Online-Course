#include<reg51.h>
sbit led=P1^0;              //connect one led to p1.0 
sbit led2=P1^2;      
void delay(unsigned int count)
{
	unsigned int i;
	while(count)
	{
		i = 115;
		while(i > 0)
		i--;
		count--;
	}
}

void ISR_ex0(void) interrupt 0     // ISR for external interrupt INT0
{
	led = ~led; 
}



void main()
{
	EA = 1;
	EX0 = 1;
	IT0 = 1;
	while(1)
	{
		
	}
}