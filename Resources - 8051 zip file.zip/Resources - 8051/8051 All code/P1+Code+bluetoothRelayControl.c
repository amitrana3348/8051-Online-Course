#include<reg51.h>  
sbit X = P1^0;		// connect relay1 to P1.0
sbit Y = P1^1;		// connect relay2 to P1.1

void delay(unsigned int count)
{
	unsigned int i;				 
	while(count)
	{
		i = 115;
		while(i > 0)
		i--;
		count--;
	}
}


/*
Uart initialization function, call this function by passing a valid baud rate value to initialize UART
currently Supported Baud Rates are 9600,4800,2400,1200
*/
void uart_init(unsigned int baud)
{
	unsigned int a = 9600, b = 4800, c = 2400 , d = 1200; 	

	TMOD = 0x20;	// timer 1 8-bit auto-reload
	SCON = 0x50;	// Tx and Rx enable 	

	if(baud == a)
	{
		TL1 = 0xFD;	
		TH1 = 0xFD;	
	}
	if(baud == b)
	{
		TL1 = 0xFA;	
		TH1 = 0xFA;	
	}
	if(baud == c)
	{
		TL1 = 0xF4;	
		TH1 = 0xF4;	
	}
	if(baud == d)
	{
		TL1 = 0xE8;	
		TH1 = 0xE8;	
	}
	
	TR1 = 1;		// Start timer
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Trasmitting 8 bit data
Send 8-bit data while callinjg this function
to send it over UART
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void uart_write(unsigned char value)
{
	SBUF = value;
	while(!TI);
	TI = 0;
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Receiving 8-bit data
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

char uart_read()
{
	while(!RI);
	RI = 0;
	return(SBUF);
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Xmitting String
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void uart_write_text(char *str)
{
	unsigned char i=0;
	while(str[i])
		uart_write(str[i++]);
}


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Read a particular number of bytes in a string
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
void uart_read_text(void *buff, unsigned int len)
{
	unsigned int i;
	for(i=0;i<len;i++)
	{
		((char*)buff)[i]=uart_read();
	}
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Echoing received data
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
void uart_echo()
{
	uart_write(uart_read());
}


void main()
{	
	unsigned char byte;
  uart_init(9600);
	
	//P2 = 0x00;
	
	 X=0;
	 Y=0;
	 
	delay(100);
	uart_write_text("Welcome");
    while(1)
    {
		  byte = uart_read();			// receive a byte serially, wait 1 second and again send it back
			if(byte == 'A')
			{
				X = 1;
			}
			if(byte == 'a')
			{
				X = 0;
			}
			if(byte == 'B')
			{
				Y = 1;
			}
			if(byte == 'b')
			{
				Y = 0;
			}
			
		  delay(100);						//  little delay so that user can recognize it
		  uart_write(byte);				// resend received data over UART
	
	}
}
